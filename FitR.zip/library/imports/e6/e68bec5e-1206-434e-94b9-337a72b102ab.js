"use strict";
cc._RF.push(module, 'e68bexeEgZDTpS5M3pysQKr', 'audioManager');
// Script/audioManager.js

"use strict";

exports.__esModule = true;
exports["default"] = void 0;

var _global = _interopRequireDefault(require("./global"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

var AudioManager = {
  init: function init() {
    console.log("初始化音效系统");
    this._playMusic = {}; // 缓存音乐，{name: ID}

    this._playEffect = {}; // 缓存音效，{name: ID}

    this._switchMusic = true; // 音乐开关

    this._switchEffect = true; // 音效开关
    //获取本地开关设置

    var switchSetting = true; //  JSON.parse(cc.sys.localStorage.getItem("audioSwitch")) || {};

    this._switchEffect = true; //  switchSetting.switchEffect === false ? switchSetting.switchEffect : true;

    this._switchMusic = true; // switchSetting.switchMusic === false ? switchSetting.switchMusic : true;

    return this;
  },

  /**
   * 播放音效文件
   * url: 音效文件相对地址
   * loop: 是否循环播放
   */
  playEffect: function playEffect(name, loop) {
    var _this = this;

    if (loop === void 0) {
      loop = false;
    }

    if (this._switchEffect) {
      cc.loader.loadRes("./audio/" + name, cc.AudioClip, function (err, clip) {
        if (err) {
          cc.warn("【音频】音效" + name + "文件不存在");
        } else {
          _this._playEffect[name] = cc.audioEngine.playEffect(clip, loop);
        }
      });
    }
  },

  /**
   * 转换音效开关
   */
  switchEffectFunc: function switchEffectFunc() {
    this._switchEffect = !this._switchEffect;

    if (!this._switchEffect) {
      this.setStopAllEffect();
    }

    cc.sys.localStorage.setItem("audioSwitch", JSON.stringify({
      switchEffect: this._switchEffect,
      switchMusic: this._switchMusic
    }));
  },

  /**
   * 获取音效开关状态
   */
  getSwitchEffect: function getSwitchEffect() {
    return this._switchEffect;
  },

  /**
   * 暂停指定音效
   * url： 资源路径
   */
  setPauseEffect: function setPauseEffect(name) {
    var audioId = this._playEffect[name];

    if (audioId) {
      cc.audioEngine.pauseEffect(audioId);
    } else {
      cc.error("【音频】音效文件" + name + "不存在");
    }
  },

  /**
   * 暂停正在播放的所有音效
   */
  setPauseAllEffect: function setPauseAllEffect() {
    cc.audioEngine.pauseAllEffects();
  },

  /**
   * 恢复指定音效
   * url:资源路径
   */
  setResumeEffect: function setResumeEffect(name) {
    var audioId = this._playEffect[name];

    if (audioId) {
      cc.audioEngine.resumeEffect(audioId);
    } else {
      cc.error("【音频】音效文件" + name + "不存在");
    }
  },

  /**
   * 恢复当前说暂停的所有音效
   */
  setResumeAllEffect: function setResumeAllEffect() {
    cc.audioEngine.resumeAllEffects();
  },

  /**
   * 停止播放指定音效
   * url: 资源路径
   */
  setStopEffect: function setStopEffect(name) {
    var audioId = this._playEffect[name];

    if (audioId) {
      cc.audioEngine.stopEffect(audioId);
    } else {
      cc.error("【音频】音效文件" + name + "不存在");
    }
  },

  /**
   * 停止播放所有正在播放的音效
   */
  setStopAllEffect: function setStopAllEffect() {
    cc.audioEngine.stopAllEffects();
  },

  /**
   * 背景音乐播放
   * url: 资源路径
   * loop: 是否循环
   */
  playMusic: function playMusic(name, loop) {
    if (loop === void 0) {
      loop = true;
    }

    if (this._switchMusic) {
      cc.loader.loadRes("./audio/" + name, cc.AudioClip, function (err, clip) {
        cc.audioEngine.playMusic(clip, loop);
      });
    }
  },

  /**
   * 转换音乐按钮开关
   */
  switchMusicFunc: function switchMusicFunc() {
    this._switchMusic = !this._switchMusic;

    if (!this._switchMusic) {
      this.setStopMusic();
    }

    cc.sys.localStorage.setItem("audioSwitch", JSON.stringify({
      switchEffect: this._switchEffect,
      switchMusic: this._switchMusic
    }));
  },

  /**
   * 获取音乐开关状态
   */
  getSwitchMusic: function getSwitchMusic() {
    return this._switchMusic;
  },

  /**
   * 暂停当前播放音乐
   */
  setPauseMusic: function setPauseMusic() {
    cc.audioEngine.pauseMusic();
  },

  /**
   * 恢复当前被暂停音乐音乐
   */
  setResumeMusic: function setResumeMusic() {
    cc.audioEngine.resumeMusic();
  },

  /**
   * 停止播放音乐
   */
  setStopMusic: function setStopMusic() {
    cc.audioEngine.stopMusic();
  },

  /**
   * 音乐是否正在播放（验证些方法来实现背景音乐是否播放完成）
   * return boolen
   */
  isMusicPlaying: function isMusicPlaying() {
    return cc.audioEngine.isMusicPlaying();
  }
};
var _default = AudioManager;
exports["default"] = _default;
module.exports = exports["default"];

cc._RF.pop();