// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
import global from "./global";

cc.Class({
    extends: cc.Component,

    properties: {
        hongxian: {
            // ATTRIBUTES:
            default: null,        // The default value will be used only when the component attaching
                                  // to a node for the first time
            type: cc.Node, // optional, default is typeof default
            serializable: true,   // optional, default is true
        },
        lvxian: {
            // ATTRIBUTES:
            default: null,        // The default value will be used only when the component attaching
                                  // to a node for the first time
            type: cc.Node, // optional, default is typeof default
            serializable: true,   // optional, default is true
        },
        threenode: {
            // ATTRIBUTES:
            default: null,        // The default value will be used only when the component attaching
                                  // to a node for the first time
            type: cc.Node, // optional, default is typeof default
            serializable: true,   // optional, default is true
        },
    
        kuangnode: {
            // ATTRIBUTES:
            default: null,        // The default value will be used only when the component attaching
                                  // to a node for the first time
            type: cc.Node, // optional, default is typeof default
            serializable: true,   // optional, default is true
        },
        peoplenode: {
            // ATTRIBUTES:
            default: null,        // The default value will be used only when the component attaching
                                  // to a node for the first time
            type: cc.Node, // optional, default is typeof default
            serializable: true,   // optional, default is true
        },
        changenode: {
            // ATTRIBUTES:
            default: null,        // The default value will be used only when the component attaching
                                  // to a node for the first time
            type: cc.Node, // optional, default is typeof default
            serializable: true,   // optional, default is true
        },
        tipsnode: {
            // ATTRIBUTES:
            default: null,        // The default value will be used only when the component attaching
                                  // to a node for the first time
            type: cc.Node, // optional, default is typeof default
            serializable: true,   // optional, default is true
        },
        longgu: {
            // ATTRIBUTES:
            default: null,        // The default value will be used only when the component attaching
                                  // to a node for the first time
            type: cc.Node, // optional, default is typeof default
            serializable: true,   // optional, default is true
        },
        backnode: {
            // ATTRIBUTES:
            default: null,        // The default value will be used only when the component attaching
                                  // to a node for the first time
            type: cc.Node, // optional, default is typeof default
            serializable: true,   // optional, default is true
        },
        fightnode: {
            // ATTRIBUTES:
            default: null,        // The default value will be used only when the component attaching
                                  // to a node for the first time
            type: cc.Node, // optional, default is typeof default
            serializable: true,   // optional, default is true
        },
        nicenode: {
            // ATTRIBUTES:
            default: null,        // The default value will be used only when the component attaching
                                  // to a node for the first time
            type: cc.Node, // optional, default is typeof default
            serializable: true,   // optional, default is true
        },
        wownode: {
            // ATTRIBUTES:
            default: null,        // The default value will be used only when the component attaching
                                  // to a node for the first time
            type: cc.Node, // optional, default is typeof default
            serializable: true,   // optional, default is true
        },
        amazingnode: {
            // ATTRIBUTES:
            default: null,        // The default value will be used only when the component attaching
                                  // to a node for the first time
            type: cc.Node, // optional, default is typeof default
            serializable: true,   // optional, default is true
        },
        championnode: {
            // ATTRIBUTES:
            default: null,        // The default value will be used only when the component attaching
                                  // to a node for the first time
            type: cc.Node, // optional, default is typeof default
            serializable: true,   // optional, default is true
        },
        fenshulayout: {
            // ATTRIBUTES:
            default: null,        // The default value will be used only when the component attaching
                                  // to a node for the first time
            type: cc.Node, // optional, default is typeof default
            serializable: true,   // optional, default is true
        },
     
        addone: {
            // ATTRIBUTES:
            default: null,        // The default value will be used only when the component attaching
                                  // to a node for the first time
            type: cc.Prefab, // optional, default is typeof default
            serializable: true,   // optional, default is true
        },
        // @property({type: [cc.SpriteFrame], tooltip:"装饰图片"})
        // spriteFrames : Array<cc.SpriteFrame> = [];
        addtwo: {
            // ATTRIBUTES:
            default: null,        // The default value will be used only when the component attaching
                                  // to a node for the first time
            type: cc.Prefab, // optional, default is typeof default
            serializable: true,   // optional, default is true
        },
        timelabel: {
            // ATTRIBUTES:
            default: null,        // The default value will be used only when the component attaching
                                  // to a node for the first time
            type: cc.Label, // optional, default is typeof default
            serializable: true,   // optional, default is true
        },
        numlabel: {
            // ATTRIBUTES:
            default: null,        // The default value will be used only when the component attaching
                                  // to a node for the first time
            type: cc.Label, // optional, default is typeof default
            serializable: true,   // optional, default is true
        },
    },

    // LIFE-CYCLE CALLBACKS:

     onLoad () {
        window.globaljs= global
        window.jiancejs =this;  z
        cc.macro.ENABLE_TRANSPARENT_CANVAS = true;

     },

    start () {
        window.jiancejs =this;
        let self = this

        self.canfit = false
     self.hongxiantimout =    setTimeout(function(){
            self.showhongxian()

        },1000)

        global.audioManager.playMusic("zhandou",true)

        // setInterval(function(){
        //     self.addnumlabel()

        // },1000)
     

    },
    clickchanggenode(){

            if(this.longgu.active==  false){
                this.longgu.active = true
                let spine = this.longgu.getComponent(sp.Skeleton);

                spine.setAnimation(0, 'daiji', true); // 播放名为run的动画

            }else{
                this.longgu.active = false;

            }

    },
    showhongxian(){
        this.hongxian.active = true;
        let self = this;
        self.tipsnode.active = true;

        let num =50
        if(self.hongxian==null||self.hongxian.children.length==0){
            return;
        }
        // this.hongxia
        
        for(let i=0;i<self.hongxian.children.length;i++){
            setTimeout(function(){
                if(self.hongxian==null) return;

                self.hongxian.children[i].getComponent(cc.Animation).play("fadein")

            },50*i)
            setTimeout(function(){
                if(self.hongxian==null) return;

                self.hongxian.children[i].getComponent(cc.Animation).play("fadeout")

            },50*self.hongxian.children.length+50*i)

        }
    self.hongxianinter =     setInterval(function(){
        if(self.hongxian==null||self.hongxian.children.length==0){
            return;
        }
    
            for(let i=0;i<self.hongxian.children.length;i++){
                self.fadeintime=   setTimeout(function(){
                    if(self.hongxian==null) return;
                    self.hongxian.children[i].getComponent(cc.Animation).play("fadein")
    
                },50*i)
                self.fadeouttime=   setTimeout(function(){
                    if(self.hongxian==null) return;

                    self.hongxian.children[i].getComponent(cc.Animation).play("fadeout")
    
                },50*self.hongxian.children.length+50*i)
    
            }
        },50*self.hongxian.children.length*2)

        },
    showlvxian(){
        let self = window.jiancejs;

        clearTimeout(self.hongxiantimout);
        self.lvxian.active=true;
        self.hongxian.active=false;
        self.changenode.active = false
        self.tipsnode.active = false;
        clearInterval(self.hongxianinter);
        clearTimeout(self.fadeintime);
        clearTimeout(self.fadeouttime);

        setTimeout(function(){
            self.lvxian.active = false;
            self.hongxian.active=false;

            // self.fivenode.active = true;
            self.peoplenode.active =false;
            self.kuangnode.active=false
            self.backnode.active=false

            self.threenode.active = true;
            let threeanimation =  self.threenode.getComponent(cc.Animation)
            setTimeout(function(){
                global.audioManager.playEffect("go",false)

            },2000)


           threeanimation.on(cc.Animation.EventType.FINISHED, self.fight, self)
           threeanimation.play("three")

        },1000)

    },
    fight(){
        let self =  window.jiancejs
        jiancejs.threenode.active = false;
        jiancejs.fightnode.active = true;
        console.log("fight")
        self.jishiqi = 0;
        console.log("开始计时器111self.jishiqi==="+self.jishiqi)
        self.canfit = true;

        self.jishiqiinter =setInterval(function(){
            console.log("开始计时器111self.jishiqi==="+self.jishiqi)
            self.jishiqi= self.daojishi+1;
            console.log("开始计时器222self.jishiqi==="+self.jishiqi)

            if(self.daojjishiqiishi%60==0){
                //扣除一点能量
                self.energe = self.energe-1
                // if (cc.sys.isNative) {

                //     if (cc.sys.OS_ANDROID == cc.sys.os) {
                //         jsb.reflection.callStaticMethod('com/gamefi/fitr/AppActivity', 'clickback', "()V");
        
                //     }
                // }
                // clearInterval(self.jishiqiinter)
                // cc.director.loadScene("jiesuan")

                
            }else{

                // if(self.jishiqi<10){
                //     self.timelabel.string="00:0"+self.jishiqi

                // }else if(self.jishiqi){
                //     self.timelabel.string="00:"+self.jishiqi

                // }

            }


        },1000)
        

    },
    spineEventCallback(){
        let self = window.jiancejs;

        if (eventType === sp.AnimationEventType.COMPLETE && trackEntry.animation && trackEntry.animation.name === 'qitiao') {
        
           self.longgu.getComponent(sp.Skeleton).setAnimation(0, 'qitiao', false); // 播放名为run的动画
        }
    },
    addnumlabel(){
        //跳绳数目加1
        
        let self = window.jiancejs;
      
        if(self.canfit!=true){
            return;
        }
      
        if(self.longgu.active==true){

            // this.longgu.play        
            // self.longgu.getComponent(sp.Skeleton).paus

            self.longgu.getComponent(sp.Skeleton).setAnimation(1, 'dantiao', false); // 播放名为run的动画
            // spine
            // spine.setAnimationListener(self, self.spineEventCallback); // 注册回调

                // spine.setAnimation(0, 'daiji', loop); // 播放名为run的动画

        }




        self.fitnum = parseInt(self.numlabel.string)+1
        if( self.fitnum==10){
            global.audioManager.playEffect("nice",false)

            self.showbaoji(self.nicenode)

        } else  if( self.fitnum==20){
            global.audioManager.playEffect("wow",false)

            self.showbaoji(self.wownode)

        }else  if( self.fitnum==35){
            global.audioManager.playEffect("amazing",false)

            self.showbaoji(self.amazingnode)

        }else  if( self.fitnum==50){
            global.audioManager.playEffect("champion",false)

            self.showbaoji(self.championnode)

        }
        if(self.fitnum%3==0){
            if(self.baojinum==null){
                self.baojinum = 0
            }
            self.baojinum =  self.baojinum+1
            // self.showbaoji()
                 
        let pre =  cc.instantiate(self.addtwo)
        pre.y = 380;
        pre.x = Math.random() * 600-300
        global.audioManager.playEffect("addtwo",false)

        self.fenshulayout.addChild(pre);

        }else{
            global.audioManager.playEffect("addone",false)

     
            let pre =  cc.instantiate(self.addone)
            pre.y = 380;
            pre.x = (Math.random() * 150 - (-150) +1 ) + (-150)
            self.fenshulayout.addChild(pre);
        }

        self.numlabel.string = self.fitnum+"";

     
    },
    
    showbaoji(node){
        let self = this;
        // node.active = true;
        // let x = (Math.random() * 150 - (-150) +1 ) + (-150)
        // node.x = x;
        // self.baojinode.x=
        let baojianimation =  node.getComponent(cc.Animation)

        // baojianimation.on(cc.Animation.EventType.FINISHED, self.baojiover, self)
        baojianimation.play("baoji")

    },
    baojiover(){
        let self = this;
        // self.nicenode.active = false;
        // self.wownode.active = false;
        // self.amazingnode.active = false;
        // self.championnode.active=false;
        // self.baojinode.active = false;
    },
    clickback(){
        // clearAll
        console.log("clickback====")
        let self = window.jiancejs;
        clearInterval(self.hongxianinter);
        clearTimeout(self.fadeintime);
        clearTimeout(self.fadeouttime);

        cc.director.loadScene("game")

        if (cc.sys.isNative) {
            if (cc.sys.OS_ANDROID == cc.sys.os) {
                jsb.reflection.callStaticMethod('com/gamefi/fitr/AppActivity', 'clickback', "()V");

            }
        }
        // setTimeout
        

    
       


    },
    loadscene(){
        cc.director.loadScene("game")

    }
    // update (dt) {},
});
