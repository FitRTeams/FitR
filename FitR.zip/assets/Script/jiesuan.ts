// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

const {ccclass, property} = cc._decorator;
import global = require( "./global");

@ccclass
export default class NewClass extends cc.Component {

    @property(cc.Label)
    baojinum: cc.Label = null;
    @property(cc.Label)
    fitnum: cc.Label = null;
 

    @property(cc.Node)
    topview: cc.Node = null;
 
    @property(cc.Node)
    xing1: cc.Node = null;
    @property(cc.Node)
    xing2: cc.Node = null;
    @property(cc.Node)
    xing3: cc.Node = null;
    @property(cc.Node)
    xing: cc.Node = null;
    
    @property(cc.Node)
    fenshunode: cc.Node = null;

    @property(cc.Node)
    kjnode: cc.Node = null;
    
    @property(cc.Node)
    rewardnode: cc.Node = null;

    @property(cc.Node)
    sharebutton: cc.Node = null;
    @property(cc.Node)
    returnbutton: cc.Node = null;

    @property(cc.Node)
    amazingnode: cc.Node = null;
    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    start () {


        let self =this;
        let jiancejs= window.jiancejs;
        global.audioManager.playEffect("jiesuan",false)

        // for(let i=0;i<this.node.children.length;i++){
        //  setTimeout(function () {
        //        let scaleto =  cc.scaleTo(0.3,1,1)
        //         this.node.children[i].runAction(scaleto);

        //     }.bind(this),50*i)
        // }
        

        let time= 0.3
        cc.tween(self.amazingnode)
        .to(time, {x:92,y:-372})
        .start();
        cc.tween(self.xing)
        .to(time, {x:0,y:0})
        .start();

        cc.tween(self.fenshunode)
        .to(time, {x:209,y:-90})
        .start();
        cc.tween(self.kjnode)
        .to(time, {x:-225,y:-275})
        .start();

        cc.tween(self.rewardnode)
        .to(time, {x:60,y:-239})
        .start();

        cc.tween(self.sharebutton)
        .to(time, {x:178,y:-584})
        .start();

        cc.tween(self.returnbutton)
        .to(time, {x:-162,y:-584})
        .start();
        // cc.tween(self.xing3)
        // .to(time, {x:19.292,y:-92.745})
        // .start();
        // cc.tween(self.xing2)
        // .to(time, {x:-131.858,y:-108.551})
        // .start();

        // cc.tween(self.xing1)
        // .to(time, {x:-131.858,y:-108.551})
        // .start();


        let num  = jiancejs.fitnum
        if(jiancejs.baojinum==undefined){
            jiancejs.baojinum=0
        }
        self.baojinum.string = "+"+jiancejs.baojinum;
    

        // window.jiesuan = this;
        setTimeout(function(){
            for (let i = 0; i < jiancejs.baojinum; i++) {
            
                self.scheduleOnce(function(){
                    //定义的是 node节点，需要获得node节点上的Label组件
                    //再对Label组件里的string属性赋值
                    self.fitnum.string = num
                    //如果定义的是cc.Label 可直接使用
                    //this.m_label.string = num
                    num++
                },(2/jiancejs.baojinum)*i)
            }
        },600)
       
   

    }
    clickreturn(){

        cc.director.loadScene("game")

    }

    // update (dt) {}
}
