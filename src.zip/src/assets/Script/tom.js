cc.Class({
extends: cc.Component,
properties: {},
onLoad() {
cc.macro.ENABLE_TRANSPARENT_CANVAS = !0;
},
start() {}
});