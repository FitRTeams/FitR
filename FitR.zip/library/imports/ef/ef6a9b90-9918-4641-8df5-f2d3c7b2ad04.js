"use strict";
cc._RF.push(module, 'ef6a9uQmRhGQY318tPHsq0E', 'global');
// Script/global.js

"use strict";

exports.__esModule = true;
exports["default"] = void 0;

var _audioManager = _interopRequireDefault(require("./audioManager"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

var global = global || {};
global.audioManager = _audioManager["default"].init();
var _default = global;
exports["default"] = _default;
module.exports = exports["default"];

cc._RF.pop();