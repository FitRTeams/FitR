// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

const {ccclass, property} = cc._decorator;

@ccclass
export default class buttonview extends cc.Component {

    @property(cc.Node)
    one: cc.Node = null;
    @property(cc.Node)
    two: cc.Node = null;
     @property(cc.Node)
    three: cc.Node = null;
   

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    start () {
        this.one.active = true;

    }
    clearbuttonview(){
        this.one.active = false;
        this.two.active = false;
        this.three.active = false;

    }

    clickone(){
        if(this.one.active == true){
            return;
        }else{
            this.clearbuttonview();
            this.one.active = true; 
        }
    }
    clicktwo(){
        if(this.two.active == true){
            return;
        }else{
            this.clearbuttonview();
            this.two.active = true; 
        }
    }
    clickthree(){
        if(this.three.active == true){
            return;
        }else{
            this.clearbuttonview();
            this.three.active = true; 
        }
    }

    // update (dt) {}
}
