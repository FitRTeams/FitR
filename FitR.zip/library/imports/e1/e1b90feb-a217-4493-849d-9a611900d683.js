"use strict";
cc._RF.push(module, 'e1b90/rohdEk4SdmmEZANaD', 'Game');
// Script/Game.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
//游戏主场景
var global = require("./global");
var Helloworld = /** @class */ (function (_super) {
    __extends(Helloworld, _super);
    function Helloworld() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.startbutton = null;
        _this.topview = null;
        _this.diview = null;
        _this.topchild1 = null;
        _this.topchild2 = null;
        _this.topchild3 = null;
        _this.topchild4 = null;
        _this.energenum = null;
        _this.energeremain = null;
        _this.rewardnum = null;
        _this.linkdialog = null;
        _this.noNFTnode = null;
        _this.noEnergenode = null;
        // clickedtrue;
        // @property
        // text: string = 'hello';
        _this.clicked = false;
        return _this;
    }
    Helloworld.prototype.start = function () {
        this.clicked = false;
        // init logic
        // this.label.string = this.text;
        // console.log("清楚缓存d21")
        cc.macro.ENABLE_TRANSPARENT_CANVAS = true;
        // cc.director.setClearColor(new cc.Color(0,0,0, 0))
        //  cc.director.setClearColor(cc.color(255, 255, 255, 0));
        // 
        global.audioManager.playMusic("zhujiemian", true);
        this.showjinchang();
    };
    Helloworld.prototype.showlinkdialog = function () {
        this.linkdialog.active = true;
    };
    Helloworld.prototype.closelinkdialog = function () {
        this.linkdialog.active = false;
    };
    Helloworld.prototype.shownoNFTdialog = function () {
        this.noNFTnode.active = true;
    };
    Helloworld.prototype.closenoNFTdialog = function () {
        this.noNFTnode.active = false;
    };
    Helloworld.prototype.shownoEnergedialog = function () {
        this.noEnergenode.active = true;
    };
    Helloworld.prototype.closenoEnergedialog = function () {
        this.noEnergenode.active = false;
    };
    Helloworld.prototype.showjinchang = function () {
        var self = this;
        // cc.Tween
        var time = 0.3;
        cc.tween(self.diview)
            .to(time, { y: -684 })
            .start();
        cc.tween(self.topview)
            .to(time, { y: 661.423 })
            .start();
        // cc.tween(self.topchild1)
        // .to(time, {y: -66.169})
        // .start();
        // cc.tween(self.topchild2)
        // .to(time, {y: 67.696})
        // .start();
        // cc.tween(self.topchild3)
        // .to(time, {y: 201.686})
        // .start();
        cc.tween(self.topchild4)
            .to(time, { x: 330.576 })
            .start();
    };
    Helloworld.prototype.clickstart = function () {
        //游戏开始  判断是否有能量  如果没有 则开始不了 如果有的话 正常扣除能量
        //定义计时器  1分钟或者几分钟
        //检测人体 检测成功 则开始计时器倒计时
        //在canvas里面 设置计时器 非游戏内内容  需要在安卓端设计计时器  
        //  是否有暂定和提前结束按钮
        // let energe = 1;
        // if(energe ==0){
        //     window.alert ("Energe is not Energe")
        // }else{
        //     energe = energe -1;
        // }
        // console.log("清楚缓存d22")
        // console.log("click start")
        // this.startbutton.active = false;
        // this.back
        // this.
        if (this.clicked == true) {
            return;
        }
        else {
            this.clicked = true;
        }
        // cc.loader.lo("jiance")
        if (cc.sys.isNative) {
            if (cc.sys.OS_ANDROID == cc.sys.os) {
                jsb.reflection.callStaticMethod('com/gamefi/fitr/AppActivity', 'getPermission', "()V");
            }
        }
        setTimeout(function () {
            global.audioManager.setPauseMusic();
            cc.director.loadScene("jiance");
        }, 2000);
    };
    __decorate([
        property(cc.Node)
    ], Helloworld.prototype, "startbutton", void 0);
    __decorate([
        property(cc.Node)
    ], Helloworld.prototype, "topview", void 0);
    __decorate([
        property(cc.Node)
    ], Helloworld.prototype, "diview", void 0);
    __decorate([
        property(cc.Node)
    ], Helloworld.prototype, "topchild1", void 0);
    __decorate([
        property(cc.Node)
    ], Helloworld.prototype, "topchild2", void 0);
    __decorate([
        property(cc.Node)
    ], Helloworld.prototype, "topchild3", void 0);
    __decorate([
        property(cc.Node)
    ], Helloworld.prototype, "topchild4", void 0);
    __decorate([
        property(cc.Label)
    ], Helloworld.prototype, "energenum", void 0);
    __decorate([
        property(cc.Label)
    ], Helloworld.prototype, "energeremain", void 0);
    __decorate([
        property(cc.Label)
    ], Helloworld.prototype, "rewardnum", void 0);
    __decorate([
        property(cc.Node)
    ], Helloworld.prototype, "linkdialog", void 0);
    __decorate([
        property(cc.Node)
    ], Helloworld.prototype, "noNFTnode", void 0);
    __decorate([
        property(cc.Node)
    ], Helloworld.prototype, "noEnergenode", void 0);
    Helloworld = __decorate([
        ccclass
    ], Helloworld);
    return Helloworld;
}(cc.Component));
exports.default = Helloworld;

cc._RF.pop();