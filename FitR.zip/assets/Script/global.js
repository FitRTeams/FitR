import AudioManager from "./audioManager";

const global = global || {};
global.audioManager = AudioManager.init();
export default global;
