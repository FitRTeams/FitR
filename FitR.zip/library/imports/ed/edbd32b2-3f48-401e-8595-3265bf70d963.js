"use strict";
cc._RF.push(module, 'edbd3KyP0hAHoWVMmW/cNlj', 'jiesuan');
// Script/jiesuan.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var global = require("./global");
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.baojinum = null;
        _this.fitnum = null;
        _this.topview = null;
        _this.xing1 = null;
        _this.xing2 = null;
        _this.xing3 = null;
        _this.xing = null;
        _this.fenshunode = null;
        _this.kjnode = null;
        _this.rewardnode = null;
        _this.sharebutton = null;
        _this.returnbutton = null;
        _this.amazingnode = null;
        return _this;
        // update (dt) {}
    }
    // LIFE-CYCLE CALLBACKS:
    // onLoad () {}
    NewClass.prototype.start = function () {
        var self = this;
        var jiancejs = window.jiancejs;
        global.audioManager.playEffect("jiesuan", false);
        // for(let i=0;i<this.node.children.length;i++){
        //  setTimeout(function () {
        //        let scaleto =  cc.scaleTo(0.3,1,1)
        //         this.node.children[i].runAction(scaleto);
        //     }.bind(this),50*i)
        // }
        var time = 0.3;
        cc.tween(self.amazingnode)
            .to(time, { x: 92, y: -372 })
            .start();
        cc.tween(self.xing)
            .to(time, { x: 0, y: 0 })
            .start();
        cc.tween(self.fenshunode)
            .to(time, { x: 209, y: -90 })
            .start();
        cc.tween(self.kjnode)
            .to(time, { x: -225, y: -275 })
            .start();
        cc.tween(self.rewardnode)
            .to(time, { x: 60, y: -239 })
            .start();
        cc.tween(self.sharebutton)
            .to(time, { x: 178, y: -584 })
            .start();
        cc.tween(self.returnbutton)
            .to(time, { x: -162, y: -584 })
            .start();
        // cc.tween(self.xing3)
        // .to(time, {x:19.292,y:-92.745})
        // .start();
        // cc.tween(self.xing2)
        // .to(time, {x:-131.858,y:-108.551})
        // .start();
        // cc.tween(self.xing1)
        // .to(time, {x:-131.858,y:-108.551})
        // .start();
        var num = jiancejs.fitnum;
        if (jiancejs.baojinum == undefined) {
            jiancejs.baojinum = 0;
        }
        self.baojinum.string = "+" + jiancejs.baojinum;
        // window.jiesuan = this;
        setTimeout(function () {
            for (var i = 0; i < jiancejs.baojinum; i++) {
                self.scheduleOnce(function () {
                    //定义的是 node节点，需要获得node节点上的Label组件
                    //再对Label组件里的string属性赋值
                    self.fitnum.string = num;
                    //如果定义的是cc.Label 可直接使用
                    //this.m_label.string = num
                    num++;
                }, (2 / jiancejs.baojinum) * i);
            }
        }, 600);
    };
    NewClass.prototype.clickreturn = function () {
        cc.director.loadScene("game");
    };
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "baojinum", void 0);
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "fitnum", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "topview", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "xing1", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "xing2", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "xing3", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "xing", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "fenshunode", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "kjnode", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "rewardnode", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "sharebutton", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "returnbutton", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "amazingnode", void 0);
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(cc.Component));
exports.default = NewClass;

cc._RF.pop();