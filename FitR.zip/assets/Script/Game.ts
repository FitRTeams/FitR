const {ccclass, property} = cc._decorator;
//游戏主场景
import global = require( "./global");

@ccclass
export default class Helloworld extends cc.Component {

    @property(cc.Node)
    startbutton: cc.Node = null;




    @property(cc.Node)
    topview: cc.Node = null;


    @property(cc.Node)
    diview: cc.Node = null;

    @property(cc.Node)
    topchild1: cc.Node = null;
    @property(cc.Node)
    topchild2: cc.Node = null;
    @property(cc.Node)
    topchild3: cc.Node = null;
    @property(cc.Node)
    topchild4: cc.Node = null;

    @property(cc.Label)
    energenum: cc.Label = null;
    @property(cc.Label)
    energeremain: cc.Label = null;

    @property(cc.Label)
    rewardnum: cc.Label = null;


    @property(cc.Node)
    linkdialog: cc.Node = null;

    @property(cc.Node)
    noNFTnode: cc.Node = null;
    @property(cc.Node)
    noEnergenode: cc.Node = null;
    // clickedtrue;
    // @property
    // text: string = 'hello';

    clicked:Boolean = false;
    start () {
        this.clicked = false;
        // init logic
        // this.label.string = this.text;
        // console.log("清楚缓存d21")
        cc.macro.ENABLE_TRANSPARENT_CANVAS = true;
        // cc.director.setClearColor(new cc.Color(0,0,0, 0))
        //  cc.director.setClearColor(cc.color(255, 255, 255, 0));


        // 
       
        global.audioManager.playMusic("zhujiemian",true)
        this.showjinchang();


    }
    showlinkdialog(){
        this.linkdialog.active = true;
    }
    closelinkdialog(){
        this.linkdialog.active = false;
    }

    shownoNFTdialog(){
        this.noNFTnode.active = true;
    }
    closenoNFTdialog(){
        this.noNFTnode.active = false;
    }


    shownoEnergedialog(){
        this.noEnergenode.active = true;
    }
    closenoEnergedialog(){
        this.noEnergenode.active = false;
    }






    showjinchang(){
        let self = this;
// cc.Tween
        let time= 0.3
        cc.tween(self.diview)
        .to(time, {y: -684})
        .start();
        cc.tween(self.topview)
        .to(time, {y: 661.423})
        .start();

// cc.tween(self.topchild1)
// .to(time, {y: -66.169})
// .start();

// cc.tween(self.topchild2)
// .to(time, {y: 67.696})
// .start();
// cc.tween(self.topchild3)
// .to(time, {y: 201.686})
// .start();
        cc.tween(self.topchild4)
        .to(time, {x: 330.576})
        .start();
    }
    clickstart(){
        //游戏开始  判断是否有能量  如果没有 则开始不了 如果有的话 正常扣除能量
        //定义计时器  1分钟或者几分钟
        //检测人体 检测成功 则开始计时器倒计时
        //在canvas里面 设置计时器 非游戏内内容  需要在安卓端设计计时器  
        //  是否有暂定和提前结束按钮
        // let energe = 1;
        // if(energe ==0){
        //     window.alert ("Energe is not Energe")
        // }else{
        //     energe = energe -1;

        // }
        // console.log("清楚缓存d22")

        // console.log("click start")
        // this.startbutton.active = false;
        // this.back
        // this.

        
        if(this.clicked==true){
            return
        }else{
            this.clicked = true;
        }

        // cc.loader.lo("jiance")
        if (cc.sys.isNative) {
            if (cc.sys.OS_ANDROID == cc.sys.os) {
                jsb.reflection.callStaticMethod('com/gamefi/fitr/AppActivity', 'getPermission', "()V");

            }
        }
        setTimeout(function(){
            global.audioManager.setPauseMusic()

            cc.director.loadScene("jiance")
            
            

        },2000)


    }



} 
