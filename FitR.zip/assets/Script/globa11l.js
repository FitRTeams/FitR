// import defines from "./data/defines";
// import AudioManager from "./util/audioManager";

// const global = global || {};
// global.audioManager = AudioManager.init();
// global.adBuyGunInterval = null;
// global.showFreeAdGun = true;
// global.supplyInterval = null;
// global.adsFreeIndex = -1;
// global.supplyTimeouter = null;
// global.shopItems= [];
// global.labelFont = null;
// //global.havead = false
// global.initUserData = {
//     gold: 1000,
//    //debug   gold: 1000,
//     gem: 30,
//     buyCount: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
//     gemBuyCount: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
//     stage: 1,
//     maxUnlock: 1,
//     selectGunLv: 1,
//     selectLv: 1,
//     slotConfig: [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], // [gunId]
//     supplyTimes: 0,
//     quickBuyGunLv: 0,
//     energy: 5,
//     energyLastRecoverAt: -1,
//     checkEnergy: 1,
//     isNewer: 1,
//     guideStep: 1,
//     useNewTutorial: 1,
//     storeGuide:1,
//     speedUpGuide:1,
//     supplyBoxGuide:1,
//     shootLevelGuide:0,
//     lastLeaveGame:0,
//     vibrateAble: true,
//     giftPkgTimes: 5,
//     lastGiftPkgTime: 0,
//     shootTimes: 0,
//     moneySpeed: 0,
// };

// global.config = {
//     supplyLevelLimit: 7,
//     supplyBoxValueLimit: [ -2, -4, -5, -6 ],
//     supplyBoxGunLimit: [ 10, 16 ],
//     supplyBoxCountLimit: 8,
//     supplyBoxShowInterval: 60,// 60
//     energyUpdateIntervalS: 360,//360
//     energyMax: 5,
//     shootLevelRewardRatio: .1,
//     maxOfflinePeriod: 7200, // 离线收益最大奖励, s
//     minOfflinePeriod: 120, // s
//     adsFreeCheckInterval: 300,//10
//     adsFreeGunLimitLevel: 11,
//     adsFreeGunConfig: [ [ -1, .2 ], [ -2, .4 ] ],
//     shootingAwardHitLimitRatio: 10,
//     reciolDuration: 0.15,
//     recoverDuration: 0.35,


//     inviteLimit: 30,
//     shareRewardTimes: 2,
//     offlineDiamondPrice: 10,
//     offlineDiamondTimes: 10,
//     adsUpgradeLevel: 10,
//     autoDropLevel: 10,
//     tutorialBake: 1,
//     videoAdsInterval: 10,
//     hideAdsEnable: 0,
//     hideAdsInterval: 10,
//     moneyAdsEnable: 1,
//     dailyGiftAdsCount: 3,
//     dailyGiftShareCount: 3,
//     collectRewardGem: 200,
//     shootRewardShare: 0,
//     casinoLimit: 50,
//     casinoShare: 0,
//     supplyShare: 0,
//     slotTimeShare: 0,
//     casinoPlayTimes: 5,
//     scoreLevelEnable: 1,
//     dailyShootDiamonds: 430,
//     maxChallengeLevel: 150,
//     shootLevelRewardShare: 1,
//     scoreLevelConfig: [ [ [ 1, 1 ], [ 2, -1 ], [ 1, -1 ] ], [ [ 1, 3 ], [ 2, 1 ], [ 1, 2 ], [ 2, -1 ], [ 1, -1 ] ], [ [ 1, 5 ], [ 2, 1 ], [ 1, 3 ], [ 2, 1 ], [ 1, 2 ], [ 2, -1 ], [ 1, -1 ] ] ],
//     shareSuccessTimeOutMS: 3000,
//     shareRewardTimeOutS: 300,
//     buyBtnFreeUpgradeLevel: 20,
//     diamondSpeedupPeriod: 60,
//     adsSpeedupPeriod: 200,
//     diamondSpeedupPrice: 10,
//     allowPauseDrag: 1,
//     dailyGiftMinAward: 10,
//     shootingRoundDurationM: 1,
//     shootingAwardTenLimitRatio: 1.14,
//     dailyShareOpen: 0,
//     sceneReviewList: [ 1005, 1006, 1011, 1012, 1013, 1027, 1042, 1047, 1048, 1049, 1053, 1054 ],
//     shootingLevelDurationM: .5,
// };
// global.maxGun = 50;
// global.canOpenBox = false;

// global.gun = {
//     getGunInfo:function (id) {
//         let gunInfo = null;
//         defines.gunConfig.map((item)=>{
//             if(item.id === id) gunInfo = item;
//         });
//         return gunInfo
//     }
// };
// global.getNewMaxInstanceId = function() {
//     defines.maxInstanceId += 1;
//     return defines.maxInstanceId
// };
// global.buyPrice = function (gunId) {
//     let buyTimes = global.user.buyCount[gunId-1];
//     return gunId == 1 ? Math.floor(Math.round(.51 * buyTimes * buyTimes + 4.62 * buyTimes + 112.41)) : Math.floor(Math.round(defines.gunPrice[gunId-1] * Math.pow(Math.E, .1613 * buyTimes)));
// };

// global.gemBuyPrice = function(gunId) {
//     let buyTimes = global.user.gemBuyCount[gunId-1];
//     let baseGemPrice = defines.gunGemPrice[gunId-1];
//     return buyTimes <= 0 ? baseGemPrice : Math.round(baseGemPrice * Math.pow(1.5, buyTimes));
// };

// global.saveUserData = function() {
//     global.user.lastLeaveGame = Date.now();
//     let saveDataString = JSON.stringify(global.user);
//     cc.sys.localStorage.setItem("userData", saveDataString);
// };

// global.getUserData = function() {
//     let saveDataString = cc.sys.localStorage.getItem("userData");
//     if(saveDataString){
//         global.user = JSON.parse(saveDataString);
//     }else{
//         // new user
//         global.user = global.initUserData;
//     }
// };
// global.getMaxGoldBuy = function() {
//     let confId = global.user.maxUnlock >= 6 ? 5 : global.user.maxUnlock - 1;
//     let unlockConfigItem = defines.unlockShowConfig[confId];
//     let unknowLevel = unlockConfigItem[3], gemLevel = unlockConfigItem[2], goldLevel = unlockConfigItem[1];
//     if(goldLevel == -1){
//         goldLevel = global.user.maxUnlock - unknowLevel - gemLevel;
//     }
//     return goldLevel;
// };

// global.isShotGun = function(e) {
//     return defines.shotGuns.indexOf(e) >= 0;
// };
// global.isHandGun = function(e) {
//     return defines.handGun.indexOf(e) >= 0;
// };
// global.isSubmachineGun = function(e) {
//     return defines.submachineGun.indexOf(e) >= 0;
// };
// global.isMachineGun = function(e) {
//     return defines.machineGun.indexOf(e) >= 0;
// };
// global.isGatlingGun = function(e) {
//     return defines.gatlingGun.indexOf(e) >= 0;
// };
// global.isSniperGun = function(e) {
//     return defines.sniperGun.indexOf(e) >= 0;
// };
// global.isAssaultRifle = function(e) {
//     return defines.assaultRifle.indexOf(e) >= 0;
// };


// global.playGunShootSound = function(gunId) {
//     if (global.audioManager._switchMusic) {
//         if(gunId == 4){
//             global.audioManager.playEffect("shoot_4", false);
//             return null;
//         }
//         if(gunId == 6){
//             global.audioManager.playEffect("shoot_5", false);
//             return null;
//         }
//         if(gunId == 8){
//             global.audioManager.playEffect("shoot_6", false);
//             return null;
//         }
//         if(gunId == 9){
//             global.audioManager.playEffect("shoot_7", false);
//             return null;
//         }

//         if(global.isHandGun(gunId)){
//             global.audioManager.playEffect("hand_gun", false);
//         }else if(global.isShotGun(gunId)){
//             global.audioManager.playEffect("shot_gun", false);
//         }else{
//             if(global.isSubmachineGun(gunId)){
//                 // global.audioManager.playEffect("shoot_submachine", true);
//                 global.audioManager.playEffect("shoot_submachine", false);
//                 return "shoot_submachine";
//             }
//             if(global.isMachineGun(gunId)){
//                 // global.audioManager.playEffect("shoot_machine", true);
//                 global.audioManager.playEffect("shoot_machine", false);
//                 return "shoot_machine";
//             }
//             if(global.isGatlingGun(gunId)){
//                 // global.audioManager.playEffect("shoot_gatling", true);
//                 global.audioManager.playEffect("shoot_gatling", false);
//                 return "shoot_gatling";
//             }

//             if(global.isSniperGun(gunId)){
//                 global.audioManager.playEffect("shoot_sniper", false);
//             }else{
//                 if(global.isAssaultRifle(gunId)){
//                     // global.audioManager.playEffect("shoot_assaultRifle", true);
//                     global.audioManager.playEffect("shoot_assaultRifle", false);
//                     return "shoot_assaultRifle";
//                 }else{
//                     global.audioManager.playEffect("hand_gun", false);
//                 }
//             }
//         }
//         return null;
//     }
// };

// !function(e) {
//     e[e.BOTTLE = 1] = "BOTTLE", e[e.WINE_BOTTLE_RED = 2] = "WINE_BOTTLE_RED", e[e.WINE_BOTTLE_GREEN = 3] = "WINE_BOTTLE_GREEN",
//         e[e.CHAMPAGNE = 4] = "CHAMPAGNE", e[e.DISH = 5] = "DISH", e[e.PAPER_BOX = 6] = "PAPER_BOX",
//         e[e.SIGNAL_CARD = 7] = "SIGNAL_CARD", e[e.IRON_CARD = 8] = "IRON_CARD", e[e.WOOD_BOX = 9] = "WOOD_BOX",
//         e[e.WOOD_BOX2 = 10] = "WOOD_BOX2", e[e.BUCKET = 11] = "BUCKET";
// }(global.materials || (global.materials = {}));

// global.playMaterialHitSound = function(mid) {
//     if(mid == global.materials.BOTTLE || mid == global.materials.WINE_BOTTLE_RED || mid == global.materials.WINE_BOTTLE_GREEN || mid == global.materials.CHAMPAGNE || mid == global.materials.DISH){
//         global.audioManager.playEffect("hit_glass", false);
//     }else if(mid == global.materials.PAPER_BOX){
//         global.audioManager.playEffect("hit_box", false);
//     }else if(mid == global.materials.WOOD_BOX || mid == global.materials.WOOD_BOX2){
//         global.audioManager.playEffect("hit_wood", false);
//     }else if(mid == global.materials.IRON_CARD || mid == global.materials.SIGNAL_CARD || mid == global.materials.BUCKET){
//         global.audioManager.playEffect("hit_iron", false);
//     }
// }

// global.playMaterialBreakSound = function(mid) {
//     if(mid == global.materials.BOTTLE || mid == global.materials.WINE_BOTTLE_RED || mid == global.materials.WINE_BOTTLE_GREEN || mid == global.materials.CHAMPAGNE || mid == global.materials.DISH){
//         global.audioManager.playEffect("break_glass", false);
//     }else if(mid == global.materials.PAPER_BOX){
//         global.audioManager.playEffect("break_box", false);
//     }else if(mid == global.materials.WOOD_BOX || mid == global.materials.WOOD_BOX2){
//         global.audioManager.playEffect("break_wood", false);
//     }else if(mid == global.materials.IRON_CARD || mid == global.materials.SIGNAL_CARD){
//         global.audioManager.playEffect("break_iron", false);
//     }else if(mid == global.materials.BUCKET){
//         global.audioManager.playEffect("break_iron_bucket", false);
//     }
// };

// global.getAnglePos = function(e, t) {
//     let i = t, o = 0, n = 0;
//     return 90 >= i ? (o = Math.sin(180 * i / Math.PI) * e, n = -Math.cos(180 * i / Math.PI) * e) : 180 >= i ? (i -= 90,
//         o = Math.cos(180 * i / Math.PI) * e, n = Math.sin(180 * i / Math.PI) * e) : 270 >= i ? (i -= 180,
//         o = -Math.sin(180 * i / Math.PI) * e, n = Math.cos(180 * i / Math.PI) * e) : (i -= 270,
//         o = -Math.cos(180 * i / Math.PI) * e, n = -Math.sin(180 * i / Math.PI) * e), [ o, n ];
// };

// global.getEnergyRecoverLeft = function() {
//     let timeNow = new Date().getTime();
//     return global.user.energyLastRecoverAt > 0 ? Math.floor((global.user.energyLastRecoverAt + 1000 * global.config.energyUpdateIntervalS - timeNow) / 1000) : 0;
// };

// global.startScheduleEnergyUpdate = function() {
//     global.stopScheduleEnergyUpdate();
//     let i = global.getEnergyRecoverLeft();

//     i > 0 && (global.user.energyUpdateTimer = setTimeout(function() {
//         global.user.energyUpdateTimer = null;
//         global.updateEnergy(1);
//     }.bind(this), i * 1000));
// };

// global.updateEnergy = function(energy, refresh = true) {
//     void 0 === refresh && (refresh = !0);
//     let oldEnergy = global.user.energy;
//     global.user.energy += energy;
//     if(refresh){
//         if((energy < 0 && oldEnergy >= global.config.energyMax) || (energy > 0 && global.user.energy < global.config.energyMax)){
//             global.user.energyLastRecoverAt = new Date().getTime();
//             global.refreshEnergyRecoverParam();
//         }
//     }else{
//         if(global.user.energy >= global.config.energyMax){
//             global.stopScheduleEnergyUpdate();
//         }
//     }
//     global.saveUserData();
// };

// global.refreshEnergyRecoverParam = function() {
//     if (global.user.energy >= global.config.energyMax) global.stopScheduleEnergyUpdate(); else {
//         let e = 0, t = new Date().getTime();
//         if (global.user.energyLastRecoverAt <= 0 && (global.user.energyLastRecoverAt = t),
//         (e = Math.floor((t - global.user.energyLastRecoverAt) / 1e3)) >= 0) {
//             var i = Math.floor(e / global.config.energyUpdateIntervalS);
//             i > 0 && (this.updateEnergy_noCheck(i), global.user.energyLastRecoverAt = t),
//             global.user.energy < global.config.energyMax && this.startScheduleEnergyUpdate();
//         }
//     }
// };

// global.updateEnergy_noCheck = function(e) {
//     this.m_energy += e;
// }

// global.stopScheduleEnergyUpdate = function() {
//     null != global.user.energyUpdateTimer && (clearTimeout(global.user.energyUpdateTimer), global.user.energyUpdateTimer = null);
// };

// global.hasEnergyUpdateCD = function() {
//     return !(global.user.energy >= global.config.energyMax) && global.getEnergyRecoverLeft() > 0;
// };

// global.getNextUpdateEnergyCDString = function() {
//     let e = global.getEnergyRecoverLeft();
//     return 0 > e && (e = 0), global.getTimeFormatString(e);
// };

// global.getTimeFormatString = function(e) {
//     e = Math.floor(e);
//     var t = Math.floor(e / 60), i = e % 60;
//     return (10 > t ? "0" : "") + t + ":" + (10 > i ? "0" : "") + i;
// };

// global.getGunRes = function (id, sprite, callback) {
//     cc.loader.loadRes("./gun/gun_" + id, cc.SpriteFrame, (err, result) => {
//         if (err) {
//             cc.log("load res err", err)
//         } else {
//             sprite.spriteFrame = result;
//             callback && callback();
//         }
//     });
// };

// global.getMin2Power = function(e, t) {
//     void 0 === t && (t = 0);
//     let i = 0;
//     for (let o = 1; e >= o; ) i++, o = Math.pow(2, i);
//     return i + t;
// };

// global.shuffleList = function(list, times) {
//     if(times === void 0){
//         times = 1;
//     }
//     for (let i = 0, olen = list.length; i < olen * times; i++) {
//         let randomN = Math.floor(Math.random() * olen);
//         let element = list[randomN];
//         if(element != null){
//             list.splice(randomN, 1);
//             list.push(element);
//         }
//     }
// };

// global.MopubCom = null;
// global.playVideoSuccess = null;
// global.playVideoFailed = null;
// global.logEvent = (eventName)=>{
//     if(typeof(jsb) !== "undefined"){
//         let strEventName = eventName + "";
//         jsb.reflection.callStaticMethod("org/cocos2dx/javascript/AppActivity", "facebookLogEvent", "(Ljava/lang/String;)V", strEventName);
//     }
// };



// /**
//  * 将秒数值格式化为以":"分隔的时间字符串
//  */
// global.formatTimeHMS = function (seconds) {
//     seconds = Math.max(0, seconds);
//     let sec = Math.floor(seconds % 60);
//     let min = Math.floor(seconds / 60) % 60;
//     let hour = Math.floor(seconds / 3600);
//     return (hour < 10 ? '0' + hour : '' + hour) + ':' +
//         (min < 10 ? '0' + min : '' + min) + ':' +
//         (sec < 10 ? '0' + sec : '' + sec);
// };
// global.formatTimeMS = function (seconds) {
//     seconds = Math.max(0, seconds);
//     let sec = Math.floor(seconds % 60);
//     let min = Math.floor(seconds / 60) % 60;
//     return (min < 10 ? '0' + min : '' + min) + ':' +
//         (sec < 10 ? '0' + sec : '' + sec);
// };

// global.langs = {
//     "EN": {
//         "gun_name_1": "Mauser C96",
//         "gun_name_10": "Golden Revolver",
//         "gun_name_11": "S&W M327",
//         "gun_name_12": "SPAS12",
//         "gun_name_13": "M870",
//         "gun_name_14": "PPSh 41",
//         "gun_name_15": "Thompson M1928",
//         "gun_name_16": "UZI",
//         "gun_name_17": "MP7",
//         "gun_name_18": "MP5",
//         "gun_name_19": "UMP45",
//         "gun_name_2": "Desert Eagle",
//         "gun_name_20": "M60",
//         "gun_name_21": "FAMAS",
//         "gun_name_22": "AK47",
//         "gun_name_23": "M4A1",
//         "gun_name_24": "Bren MK",
//         "gun_name_25": "P90 M900",
//         "gun_name_26": "AR15",
//         "gun_name_27": "Steyr AUG",
//         "gun_name_28": "P90",
//         "gun_name_29": "KRISS Vector",
//         "gun_name_3": "Ekol Viper",
//         "gun_name_30": "SCAR",
//         "gun_name_31": "PP19",
//         "gun_name_32": "KS7",
//         "gun_name_33": "F90",
//         "gun_name_34": "GEC36",
//         "gun_name_35": "AR4 SBR",
//         "gun_name_36": "FN F2000",
//         "gun_name_37": "Wilson Combat 300BLK",
//         "gun_name_38": "HK21",
//         "gun_name_39": "Vulcan M134 A2",
//         "gun_name_4": "Colt M1911",
//         "gun_name_40": "VSS",
//         "gun_name_41": "AX338",
//         "gun_name_42": "AWM",
//         "gun_name_43": "Crush gatlin",
//         "gun_name_44": "Heavy grenade launcher",
//         "gun_name_45": "Energy cluster gun",
//         "gun_name_46": "Spark Rifle",
//         "gun_name_47": "Mega-Beam Rifle",
//         "gun_name_48": "Laser rifle",
//         "gun_name_49": "Evolver",
//         "gun_name_5": "Benelli M3",
//         "gun_name_50": "Chinese Dragon",
//         "gun_name_6": "Revolver Remington",
//         "gun_name_7": "MAC11",
//         "gun_name_8": ".44 Magnum",
//         "gun_name_9": "Punisher",
//         "txt_SignPage_again": "",
//         "txt_SignPage_no": "",
//         "txt_SignPage_success": "",
//         "txt_authPage_tip": "",
//         "txt_brushPage_buy_success": "Purchased!",
//         "txt_brushPage_operate_success": "Success!",
//         "txt_challengeEntry_best_score": "Best Record:",
//         "txt_challengeMain_error": "We encountered some problems. Please come back later!",
//         "txt_challengeMain_failed": "You Failed!",
//         "txt_constants_share1": "",
//         "txt_constants_share2": "",
//         "txt_constants_share3": "",
//         "txt_constants_share4": "",
//         "txt_constants_share5": "",
//         "txt_constants_share_new_food": "",
//         "txt_constants_share_red_pack": "",
//         "txt_helpEachOther_helpStatus_3": "",
//         "txt_helpEachOther_helpStatus_body": "",
//         "txt_language": "English",
//         "txt_newhigh": "New High Score!",
//         "txt_optionPage_title": "Language",
//         "txt_soccer_cloth_buy": "Buy",
//         "txt_soccer_cloth_cancel": "Cancel",
//         "txt_soccer_cloth_confirm": "OK",
//         "txt_soccer_cloth_help": "Help!",
//         "txt_startPage_food_cant_less_than": "",
//         "txt_startPage_food_max_food": "",
//         "txt_startPage_moneyspeed": "",
//         "txt_startPage_no_idle_disk": "",
//         "txt_startPage_recycle_food": "",
//         "txt_tap_to_close": "",
//         "txt_today_no_ad": "",
//         "txt_tutorialPage_1": "Welcome to my dessert shop! \n Let me show you how to make delicious desserts.",
//         "txt_tutorialPage_buy1_1": "Welcome to my dessert shop! \n Let me show you how to make delicious desserts.\n Click to buy a dessert",
//         "txt_tutorialPage_buy1_2": "Buy again",
//         "txt_tutorialPage_buy2_1": "Let's buy a dessert again",
//         "txt_tutorialPage_buy2_2": "Buy one more",
//         "txt_tutorialPage_buy3": "",
//         "txt_tutorialPage_gun_store": "",
//         "txt_tutorialPage_merge1": "Drag these same desserts to make a high level one.",
//         "txt_tutorialPage_merge2": "Drag these two desserts to make a high level one.",
//         "txt_tutorialPage_merge3": "Congratulations! You have learnt how to make desserts. \n Now drag these two high level desserts to make a new higher one.",
//         "txt_tutorialPage_new_buy1": "Click to buy new gun",
//         "txt_tutorialPage_new_buy2": "Buy more to merge advanced guns!",
//         "txt_tutorialPage_new_merge": "Drag and merge high-level gun",
//         "txt_tutorialPage_new_shoot": "Click to enter range",
//         "txt_tutorialPage_new_level": "Click to challenge stage",
//         "txt_tutorialPage_new_shoot2": "Try this new gun!",
//         "txt_tutorialPage_new_show": "Drag and move it ",
//         "txt_tutorialPage_shoot": "",
//         "txt_tutorialPage_shootlevel": "",
//         "txt_tutorialPage_show": "",
//         "txt_tutorialPage_speedup": "",
//         "txt_tutorialPage_supplybox": "",
//         "txt_tutorialPage_supplybox2": "",
//         "txt_rangePage_fire": "Click to fire",
//         "txt_pause": "Click to pause",
//         "txt_countdown": "Countdown",
//         "video_error": "Video closed or load error",
//     },
//     "zh-CN": {
//         "gun_name_1": "毛瑟C96手枪",
//         "gun_name_10": "黄金左轮手枪",
//         "gun_name_11": "史密斯威森m327转轮手枪",
//         "gun_name_12": "SPAS-12多功能霰弹枪",
//         "gun_name_13": "雷明登M870霰弹枪",
//         "gun_name_14": "波波沙冲锋枪",
//         "gun_name_15": "汤普逊冲锋枪",
//         "gun_name_16": "UZI冲锋枪",
//         "gun_name_17": "MP7冲锋枪",
//         "gun_name_18": "MP5冲锋枪",
//         "gun_name_19": "UMP45冲锋枪",
//         "gun_name_2": "沙漠之鹰狩猎手枪",
//         "gun_name_20": "M60通用机枪",
//         "gun_name_21": "FAMAS自动步枪",
//         "gun_name_22": "AK47突击步枪",
//         "gun_name_23": "M4A1突击步枪",
//         "gun_name_24": "布伦式轻机枪",
//         "gun_name_25": "P90 M900",
//         "gun_name_26": "AR15突击步枪",
//         "gun_name_27": "AUG突击步枪",
//         "gun_name_28": "P90自卫武器",
//         "gun_name_29": "VECTOR短剑冲锋枪",
//         "gun_name_3": "柯尔特左轮手枪",
//         "gun_name_30": "SCAR突击步枪",
//         "gun_name_31": "PP19野牛冲锋枪",
//         "gun_name_32": "KS7无托霰弹枪",
//         "gun_name_33": "F90无托步枪",
//         "gun_name_34": "G36自动步枪",
//         "gun_name_35": "AR4自动步枪",
//         "gun_name_36": "FN F2000突击步枪",
//         "gun_name_37": "威尔森战术猎手步枪",
//         "gun_name_38": "HK21通用机枪",
//         "gun_name_39": "加特林M134速射机枪",
//         "gun_name_4": "勃朗宁M1911手枪",
//         "gun_name_40": "vss狙击步枪",
//         "gun_name_41": "AX338狙击步枪",
//         "gun_name_42": "AWM狙击步枪",
//         "gun_name_43": "粉碎加特林",
//         "gun_name_44": "重型榴弹发射器",
//         "gun_name_45": "能量集束枪",
//         "gun_name_46": "火花步枪",
//         "gun_name_47": "巨型光束步枪",
//         "gun_name_48": "激射步枪",
//         "gun_name_49": "实境战斗者",
//         "gun_name_5": "M3霰弹枪",
//         "gun_name_50": "中国龙",
//         "gun_name_6": "雷明登左轮手枪",
//         "gun_name_7": "M11冲锋枪",
//         "gun_name_8": "麦林.44左轮手枪",
//         "gun_name_9": "惩罚者左轮手枪",
//         "txt_SignPage_again": "再来一份惊喜？",
//         "txt_SignPage_no": "不，谢谢！",
//         "txt_SignPage_success": "签到成功，恭喜获得",
//         "txt_authPage_tip": "授权后将帮助我们更准确的为您提供好友排行信息\n\n请允许授权.",
//         "txt_brushPage_buy_success": "购买成功~",
//         "txt_brushPage_operate_success": "操作成功~",
//         "txt_challengeEntry_best_score": "最佳纪录：",
//         "txt_challengeMain_error": "我们遇到了一些问题，请稍后再来!",
//         "txt_challengeMain_failed": "真遗憾失败了！",
//         "txt_constants_share1": "来试试你能打出多少环",
//         "txt_constants_share2": "来试试你能打出多少环",
//         "txt_constants_share3": "来试试你能打出多少环",
//         "txt_constants_share4": "来试试你能打出多少环",
//         "txt_constants_share5": "来试试你能打出多少环",
//         "txt_constants_share_new_food": "这是我制作的第%d支枪，你也一起来玩吧！",
//         "txt_constants_share_red_pack": "来试试你能打出多少环",
//         "txt_helpEachOther_helpStatus_3": "[%s]的互助礼包已达到上限~",
//         "txt_helpEachOther_helpStatus_body": "TA",
//         "txt_language": "中文",
//         "txt_newhigh": "新记录",
//         "txt_optionPage_title": "语言",
//         "txt_soccer_cloth_buy": "购买",
//         "txt_soccer_cloth_cancel": "取消",
//         "txt_soccer_cloth_confirm": "确定",
//         "txt_soccer_cloth_help": "求助",
//         "txt_startPage_food_cant_less_than": "枪械库中枪支不能低于5",
//         "txt_startPage_food_max_food": "已经是顶级枪支了",
//         "txt_startPage_moneyspeed": "%s / 秒",
//         "txt_startPage_no_idle_disk": "暂时没有空位置可以放枪了呢",
//         "txt_startPage_recycle_food": "将食物拖动到这里来丢掉",
//         "txt_tap_to_close": "点击任意位置关闭……",
//         "txt_today_no_ad": "暂时没有广告了，请稍后再试~",
//         "txt_tutorialPage_1": "欢迎来到枪火工厂！\n接下来让我教你研制秘密武器~",
//         "txt_tutorialPage_buy1_1": "开始研制秘密武器!!!\n点击购买一支枪",
//         "txt_tutorialPage_buy1_2": "再次点击购买",
//         "txt_tutorialPage_buy2_1": "接下来再购买一支枪",
//         "txt_tutorialPage_buy2_2": "再买一次",
//         "txt_tutorialPage_buy3": "让我们拭目以待你能造出多厉害的枪！",
//         "txt_tutorialPage_gun_store": "这里有便宜枪可以买哦",
//         "txt_tutorialPage_merge1": "拖动合成高级枪",
//         "txt_tutorialPage_merge2": "再拖动这两支枪合成一支高级枪",
//         "txt_tutorialPage_merge3": "恭喜!!!你已经学会了制作武器的秘诀\n拖动这两支高级枪来合成更高级的武器",
//         "txt_tutorialPage_new_buy1": "点击购买新枪",
//         "txt_tutorialPage_new_buy2": "继续点击购买\n合成更高级的武器吧！",
//         "txt_tutorialPage_new_merge": "拖动合成高级枪",
//         "txt_tutorialPage_new_shoot": "点击进入靶场",
//         "txt_tutorialPage_new_shoot2": "试试新枪",
//         "txt_tutorialPage_new_show": "拖动到展示区",
//         "txt_tutorialPage_shoot": "接下来让我们试试这把枪的威力如何！",
//         "txt_tutorialPage_shootlevel": "点击开始闯关",
//         "txt_tutorialPage_show": "拖动到展示区",
//         "txt_tutorialPage_speedup": "点击这里可以加速赚钱",
//         "txt_tutorialPage_supplybox": "打开空投可以获取大量枪支",
//         "txt_tutorialPage_supplybox2": "继续点击获取枪支",
//         "txt_rangePage_fire": "点击开枪",
//         "txt_pause": "点击暂停",
//         "txt_countdown": "倒计时",
//         "video_error": "广告被关闭或加载失败",
//     }
// }

// export default global;

// Number.prototype.toMPString = function () {
//     try {
//         let strParam = Math.floor(this).toString();
//         let flag = /e/g.test(strParam);
//         if (flag){
//             // 指数符号 true: 正，false: 负
//             let sysbol = true;
//             if (/e-/.test(strParam)) {
//                 sysbol = false
//             }
//             // 指数
//             let index = Number(strParam.match(/\d+$/)[0]);
//             // 基数
//             let basis = strParam.match(/^[\d\.]+/)[0].replace(/\./, '');

//             if (sysbol) {
//                 strParam = basis.padEnd(index + 1, 0)
//             } else {
//                 strParam = basis.padStart(index + basis.length, 0).replace(/^0/, '0.')
//             }
//         }
//         let o = ["K", "M", "B", "T", "P", "E", "Z", "Y"];
//         let t = strParam.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
//         let e = t.split(",");
//         // return e.length < 2 ? t : e[0] + "." + Math.round(Number(e[1])/100) + o[e.length - 2]
//         return e.length < 2 ? t : e[0] + "." + Math.floor(Number(e[1])/100) + o[e.length - 2]
//     } catch (t) {
//         return this
//     }
// };

// Number.prototype.toCommasString = function () {
//     try {
//         let t = this.toString().split(".");
//         t[0] = t[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
//         return t.join(".")
//     } catch (t) {
//         return this
//     }
// };