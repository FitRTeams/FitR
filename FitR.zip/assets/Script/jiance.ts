// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

const {ccclass, property} = cc._decorator;
import global from "./global";

@ccclass
export default class jiesuan extends cc.Component {

    @property(cc.Node)
    hongxian: cc.Node = null;

    @property(cc.Node)
    lvxian: cc.Node = null;
    // @property
    // text: string = 'hello';

    // LIFE-CYCLE CALLBACKS:
    hongxianinter=null;

     onLoad () {
        cc.macro.ENABLE_TRANSPARENT_CANVAS = true;

     }

    start () {
        

        this.showhongxian()
    }

   
    jiesuan(){
        cc.director.loadScene("jiesuan")
    }
    showhongxian(){
        this.hongxian.active = true;
        let self = this;
        let num =50
        // this.hongxia
        for(let i=0;i<self.hongxian.children.length;i++){
            setTimeout(function(){
                self.hongxian.children[i].getComponent(cc.Animation).play("fadein")

            },50*i)
            setTimeout(function(){
                self.hongxian.children[i].getComponent(cc.Animation).play("fadeout")

            },50*self.hongxian.children.length+50*i)

        }
    this.hongxianinter =     setInterval(function(){
            for(let i=0;i<self.hongxian.children.length;i++){
                setTimeout(function(){
                    self.hongxian.children[i].getComponent(cc.Animation).play("fadein")
    
                },50*i)
                setTimeout(function(){
                    self.hongxian.children[i].getComponent(cc.Animation).play("fadeout")
    
                },50*self.hongxian.children.length+50*i)
    
            }
        },50*self.hongxian.children.length*2)
       
        
    }
    
    showlvxian(){
        let self = this;
        self.lvxian.active=true;
        self.hongxian.active=false;
        // self.
        clearInterval(this.hongxianinter)

    }
    clickback(){
        if (cc.sys.isNative) {
            if (cc.sys.OS_ANDROID == cc.sys.os) {
                jsb.reflection.callStaticMethod('com/gamefi/fitr/AppActivity', 'clickback', "()V");

            }
        }
        // setTimeout
        setTimeout(() => {
            cc.director.loadScene("game")

        }, 1000);
       


    }
    loadscene(){
        cc.director.loadScene("game")

    }


    // update (dt) {}
}
